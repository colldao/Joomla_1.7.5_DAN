    <div id="container">  
        <ul class="menutabs">  
            <li id="news" class="active">News 1</li>  
            <li id="tutorials">News 2</li>  
            <li id="links">News 3</li>  
        </ul>  
        <span class="clear"></span>  
        <div class="content news">  
		<?php echo ($tab1); ?>
        </div>  
        <div class="content tutorials">  
		<?php echo ($tab2); ?>
        </div>  
        <div class="content links">  
		<?php echo ($tab3); ?>
        </div>  
    </div>  