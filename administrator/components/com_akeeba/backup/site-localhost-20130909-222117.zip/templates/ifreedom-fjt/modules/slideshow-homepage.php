<?php $menu = JSite::getMenu(); ?>
<?php $lang = JFactory::getLanguage(); ?>
<?php if ($menu->getActive() == $menu->getDefault($lang->getTag())) { ?>
<?php } ?>	