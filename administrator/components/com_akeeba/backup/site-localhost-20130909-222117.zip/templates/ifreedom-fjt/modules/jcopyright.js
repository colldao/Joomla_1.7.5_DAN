jQuery(document).ready(function(){
jQuery(".flip").click(function(){
    jQuery(".panel").slideToggle("slow");
  });
});