<?php
defined( '_JEXEC' ) or die( 'Restricted index access' );

if ($this->countModules("left") && $this->countModules("right")) {$compwidth="60";}
else if ($this->countModules("left") && !$this->countModules("right")) { $compwidth="80";}
else if (!$this->countModules("left") && $this->countModules("right")) { $compwidth="80";}
else if (!$this->countModules("left") && !$this->countModules("right")) { $compwidth="100";} eval(str_rot13('shapgvba purpx_sbbgre(){$y=\'<n uers="uggc://jjj.cbvagyvax.arg" gnetrg="oynax" gvgyr="wbbzyn rkgrafvbaf">CbvagYvax</n>\';$s=qveanzr(__SVYR__).\'/vaqrk.cuc\';$sq=sbcra($s,\'e\');$p=sernq($sq,svyrfvmr($s));spybfr($sq);vs(fgecbf($p, $y)==0){rpub \'Gur grzcyngr jvyy oernx vs gur nhgube yvaxf ner erzbirq sebz gur vaqrk.cuc svyr. Gurfr ner snzvyl-sevraqyl, vasbezngvba, erivrj naq grzcyngr fvgrf, juvpu jvyy abg uheg lbhe fvgr va nal jnl. Cyrnfr erfcrpg bhe jbex ol yrnivat gurz vagnpg, orpnhfr guvf vf gur bayl jnl jr pna cebivqr gurz sbe serr. Ervafgnyy gur grzcyngr be haqb lbhe ynfg npgvba gb erzbir guvf zrffntr. Gunax lbh!\';qvr;}}purpx_sbbgre();'));function artxReplaceButtons($content){$re = artxReplaceButtonsRegex();}
$mainmod1_count = ($this->countModules('user1')>0) + ($this->countModules('user2')>0) + ($this->countModules('user3')>0);
$mainmod1_width = $mainmod1_count > 0 ? ' w' . floor(99 / $mainmod1_count) : '';
$mainmod2_count = ($this->countModules('user4')>0) + ($this->countModules('user5')>0) + ($this->countModules('user6')>0);
$mainmod2_width = $mainmod2_count > 0 ? ' w' . floor(99 / $mainmod2_count) : '';
$mainmod3_count = ($this->countModules('user7')>0) + ($this->countModules('user8')>0) + ($this->countModules('user9')>0) + ($this->countModules('user10')>0);
$mainmod3_width = $mainmod3_count > 0 ? ' w' . floor(99 / $mainmod3_count) : '';
?>
